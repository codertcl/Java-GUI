package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class GamePanel extends JPanel implements KeyListener, ActionListener {
    //蛇的数据结构
    int length;
    boolean start=false;
    boolean stop=false;
    boolean fail=false;
    int[] snakeX=new int[600];
    int[] snakeY=new int[500];
    String direction;
    int foodx,foody;//食物坐标
    int bombx,bomby;//炸弹坐标
    Random random=new Random();
    int score;

    //涉及到移动速度
    Timer timer=new Timer(100,this);//定时器 100ms执行一次
    //初始化
    public GamePanel() {
        init();
        this.setFocusable(true);//获得焦点事件 显示鼠标当前所处位置
        this.addKeyListener(this);//获得键盘监听事件
        score=0;
    }

    public void init(){
        //初始化位置
        length=3;//初始三节长度
        snakeX[0]=100;snakeY[0]=100;//头坐标
        snakeX[1]=75;snakeY[1]=100;//第一节
        snakeX[2]=50;snakeY[2]=100;//第二节
        direction="R";//初始化蛇头方向向右
        timer.start();//游戏一开始就运动
        score=0;


        //随机设置食物位置
        foodx=25+25*random.nextInt(34);
        foody=25+25*random.nextInt(24);

        bombx=25+25*random.nextInt(34);
        bomby=25+25*random.nextInt(24);
    }

    //绘制面板
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(Color.WHITE);
        Data.header.paintIcon(this,g,25,11);//上方横幅
        g.fillRect(25,75,850,600);//游戏界面

        //分数
        g.setColor(Color.WHITE);
        g.setFont(new Font("楷体",Font.BOLD,20));
        g.drawString("长度"+length,750,25);
        g.drawString("分数"+score,750,50);


        Data.food.paintIcon(this,g,foodx,foody);//画食物

        Data.bomb.paintIcon(this,g,bombx,bomby);//画炸弹



        //根据方向判断蛇头位置
        if(direction.equals("R"))
        {
            Data.right.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if(direction=="L"){
            Data.left.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if(direction=="U"){
            Data.up.paintIcon(this,g,snakeX[0],snakeY[0]);
        }else if(direction=="D"){
            Data.down.paintIcon(this,g,snakeX[0],snakeY[0]);
        }


        //此处绘制身体 所以循环从1开始
        for (int i = 1; i <length ; i++) {
            Data.body.paintIcon(this,g,snakeX[i],snakeY[i]);
        }

        //未来是游戏
        if(!start){
            g.setColor(Color.WHITE);
            g.setFont(new Font("楷体",Font.BOLD,20));
            g.drawString("按下空格开始游戏",400,400);
        }

        if(fail)//失败
        {
            g.setColor(Color.RED);
            g.setFont(new Font("楷体",Font.BOLD,20));
            g.drawString("游戏失败，按空格重新开始",400,400);
        }
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }


    //不能往回走
    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();

        if (keyCode == KeyEvent.VK_SPACE)//按下了空格键
        {
            if(fail)//游戏失败
            {
                fail=false;
                init();//重新初始化
            }else {
                start=!start;//未失败按下空格 改变状态
            }
            repaint();
        }

        if (keyCode == KeyEvent.VK_UP&&direction!="D")//按下了上键  你让往回走
        {
            direction="U";
        }else if (keyCode == KeyEvent.VK_DOWN&&direction!="U")//按下了下键
        {
            direction="D";
        }else  if (keyCode == KeyEvent.VK_LEFT&&direction!="R")//按下了左键
        {
            direction="L";
        }else  if (keyCode == KeyEvent.VK_RIGHT&&direction!="L")//按下了右键
        {
            direction="R";
        }
    }



    @Override
    public void keyReleased(KeyEvent e) {

    }


    //事件监听
    @Override
    public void actionPerformed(ActionEvent e) {
        //根据移动方向 移动小蛇
        if(start&&fail==false)//游戏开始且未失败
        {
            //吃到食物
            if(snakeX[0]==foodx && snakeY[0]==foody)
            {
                length++;
                score+=10;

                //食物不在自己身上  且不与炸弹重合
                boolean flag=false;
                while(true){
                    foodx = 25 + 25*random.nextInt(34);
                    foody = 75 + 25*random.nextInt(24);//生成的随机数不能超过格子
                    for (int i = 1; i <length ; i++) {
                         if((foodx==snakeX[i]&&foody==snakeY[i])||(bombx==snakeX[i]&&bomby==snakeY[i]))
                         {
                             flag=true;
                         }
                    }
                    if(!flag)
                        break;
                }
            }
            //移动小蛇  从后向前移动
            for (int i=length-1;i>0;i--)
            {
                snakeX[i]=snakeX[i-1];//身体向前移动一节
                snakeY[i]=snakeY[i-1];
            }
            if(direction=="R")//向右走
            {
                snakeX[0]=snakeX[0]+25;
                if(snakeX[0]>850)
                {
                    snakeX[0]=25;
                }
            }else  if(direction=="L")//向左走
            {
                snakeX[0]=snakeX[0]-25;
                if(snakeX[0]<25)
                {
                    snakeX[0]=850;
                }
            }else  if(direction=="U")//向上走
            {
                snakeY[0]=snakeY[0]-25;
                if(snakeY[0]<75)
                {
                    snakeY[0]=650;
                }
            }else  if(direction=="D")//向下走
            {
                snakeY[0]=snakeY[0]+25;
                if(snakeY[0]>650)
                {
                    snakeY[0]=75;
                }
            }
            repaint();
            timer.start();//定时器移动
        }

        //失败判定 撞击到自己
        for (int i = 1; i <length ; i++) {
            if((snakeX[0]==snakeX[i]&&snakeY[0]==snakeY[i])||(snakeX[0]==bombx&&snakeY[0]==bomby))
            {
                fail=true;
            }
        }

    }
}