package com.company;

import javax.swing.*;
import com.company.Data;

public class Main {
    public static void main(String[] args) {
        // 绘制一个静态窗口
        JFrame frame = new JFrame("贪吃蛇小游戏");
        frame.setBounds(10, 10, 900, 720);
        frame.setResizable(false);//窗口大小不可变
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置关闭事件

        //2.面板
        frame.add(new GamePanel());
        frame.setVisible(true);
    }

}

