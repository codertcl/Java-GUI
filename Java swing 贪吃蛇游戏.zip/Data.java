package com.company;
import javax.swing.*;
import java.net.URL;
import javax.swing.ImageIcon;
public class Data {
    public static URL headerURL=Data.class.getResource("header.png");
    public static ImageIcon header=new ImageIcon(headerURL);

    public static URL upURL=Data.class.getResource("up.png");
    public static ImageIcon up=new ImageIcon(upURL);

    public static URL downURL=Data.class.getResource("down.png");
    public static ImageIcon down=new ImageIcon(downURL);

    public static URL leftURL=Data.class.getResource("left.png");
    public static ImageIcon left=new ImageIcon(leftURL);

    public static URL rightURL=Data.class.getResource("right.png");
    public static ImageIcon right =new ImageIcon(rightURL);

    public static URL bodyURL=Data.class.getResource("body.png");
    public static ImageIcon body =new ImageIcon(bodyURL);

    public static URL foodURL=Data.class.getResource("food.png");
    public static ImageIcon food =new ImageIcon(foodURL);

    public static URL bombURL=Data.class.getResource("bomb.png");
    public static ImageIcon bomb =new ImageIcon(bombURL);

//    public static URL brustURL=Data.class.getResource("brust.PNG");
//    public static ImageIcon brust =new ImageIcon(brustURL);

}
